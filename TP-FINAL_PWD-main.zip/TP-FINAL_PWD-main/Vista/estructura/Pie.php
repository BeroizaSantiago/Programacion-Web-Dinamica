<footer class="text-center py-4 bg-dark text-white">
    <p class="mb-1">&copy; 2024 Universidad del Comahue</p>
    <p class="mb-0">Grupo 22:</p>
    <p class="mb-0">Beroiza Santiago</p>
    <p class="mb-0">Pollio Thiago</p>
    <p class="mb-0">Salgado Sol</p>
</footer>


</html>