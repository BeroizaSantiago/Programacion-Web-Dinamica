<!-- lleva a el home para que el servidor no indexe -->
<?php
header('Location: Vista/paginas/home.php');
?>